Mavon 0.5.4
These files are website shortcuts, not native installers.
Open https://mavon-finance-moein.sturdylion256.chatgpt.site/install.html for installation instructions.
Data is stored locally on each device. Cloud sync is not available. Export a JSON backup in Settings before changing devices.
